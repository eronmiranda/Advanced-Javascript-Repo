import MyStocks from '../components/MyStocks.js'

const MyStocksList = () => {
  return <div>
    <h1>My Stocks Page</h1>
    <MyStocks/>
  </div>
}

export default MyStocks