# Assignment 4A - Stock Price Application, Converting it to React.

Please read the instructions in the [assignment PDF](dmit2008-assignment-04-pt-A.pdf)

Any other instructions should be specified by your instructor.

You can replace the entirecontents of this folder and delete what you need. Don't keep parts in the project in fyou're not using it.

